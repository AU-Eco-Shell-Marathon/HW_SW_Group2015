/*
 * safety.h
 *
 * Created: 15-05-2014 15:58:30
 *  Author: Christoffer
 */ 


#ifndef SAFETY_H_
#define SAFETY_H_

void Protection (StateType *state, volatile unsigned int *speed);


#endif /* SAFETY_H_ */