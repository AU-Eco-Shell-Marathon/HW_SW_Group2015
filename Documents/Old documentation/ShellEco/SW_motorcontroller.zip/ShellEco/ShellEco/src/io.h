/*
 * io.h
 *
 * Created: 29-04-2014 19:26:39
 *  Author: Christoffer
 */ 
#include "asf.h"


#ifndef IO_H_
#define IO_H_

void initInput(void);



#endif /* IO_H_ */