/**
 * \file
 *
 * \brief ATmega32 on STK600 board configuration template
 *
 */

#ifndef CONF_BOARD_H
#define CONF_BOARD_H

#endif // CONF_BOARD_H
