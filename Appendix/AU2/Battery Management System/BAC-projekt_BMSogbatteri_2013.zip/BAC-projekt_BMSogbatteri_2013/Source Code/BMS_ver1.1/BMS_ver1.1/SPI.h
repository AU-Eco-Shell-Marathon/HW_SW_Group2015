/*
 * SPI.h
 *
 * Created: 25-03-2013 15:17:35
 *  Author: Jonas
 */ 


void WriteByte(unsigned char data);