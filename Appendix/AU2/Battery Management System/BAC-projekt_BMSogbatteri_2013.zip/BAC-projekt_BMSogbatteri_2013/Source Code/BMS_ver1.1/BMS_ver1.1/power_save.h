/*
 * IncFile1.h
 *
 * Created: 16-04-2013 14:14:46
 *  Author: Jonas
 */ 


void CPU_speed_low(void);


void CPU_speed_high(void);

void init_sleep(void);
void CPU_enter_sleep(void);
void CPU_disable_sleep(void);